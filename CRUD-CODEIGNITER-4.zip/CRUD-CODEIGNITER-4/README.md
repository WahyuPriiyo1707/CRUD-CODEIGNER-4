# Tutorial CRUD di CodeIgniter 4

[![Build Status](https://travis-ci.org/codeigniter4/CodeIgniter4.svg?branch=develop)](https://travis-ci.org/codeigniter4/CodeIgniter4)
[![Coverage Status](https://coveralls.io/repos/github/codeigniter4/CodeIgniter4/badge.svg?branch=develop)](https://coveralls.io/github/codeigniter4/CodeIgniter4?branch=develop)
<br>

## Deskripsi Project

Inilah tutorial lengkap membuat fitur crud menggunakan codeigniter 4. 

## Cara Menjalankan Project

- Create Database dengan nama "db_ci4" pada phpmyadmin
- Import Database pada folder DB/db_ci4 ke phpmyadmin
- Open Project CI4
- Jalankan command "php spark serve"
- Done ... 
