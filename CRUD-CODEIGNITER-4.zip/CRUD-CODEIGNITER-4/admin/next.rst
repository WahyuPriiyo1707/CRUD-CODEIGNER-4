Version |version|
====================================================

Release Date: Not released

**Next alpha release of CodeIgniter4**


The list of changed files follows, with PR numbers shown.


PRs merged:
-----------

